########################################################################/
#### Escuela de Negocios Universidad Adolfo Ibañez 2022 #####
##### Aproximaciones a las políticas públicas desde los datos ##########
########### Taller 2: Procesamiento y Webscraping ######################
########################################################################/
# José Daniel Conejeros - jdconejeros@uc.cl
# Naim Bro -  naim.bro@gmail.com
# Material: https://github.com/JDConejeros/APPDD_UAI_V2022/tree/main/Talleres
# Programa del curso: https://naimbro.github.io/programa_diplomado_2022.html
########################################################################/

# En este taller nos enfocaremos:

# 1. Operar con múltiples bases de datos

# 2. Revisar las principales herramientas de Tidyverse para la importación, 
# procesamiento y análisis de datos.

########################################################################/
# 1. Trabajo con bases de datos -------------
########################################################################/

# Veamos algunas configuraciones preliminares
# Opciones de formato
options(scipen=999) # Desactiva la notación científica.
options(max.print = 99999999) # Nos permite ver más resultados en la consola.

# Vamos a trabajar con bases de datos sobre cambio climático. 

# Revise la carpeta data: ¿Cómo podemos leer bases de datos de manera simultánea? 

# Podemos trabajar guardando nuestro directorio en un objeto
directorio <- getwd()
directorio_datas <- paste0(directorio, "/03_data") 
directorio_datas

# Veamos los archivos de ese directorio
list.files(directorio)
list.files(directorio, pattern = "*.csv")
# Expresiones regulares 
list.files(directorio_datas, pattern = "*.csv") # Expresiones regulares 

# ¿Cuál es la diferencia entre .csv y .rds?
# Guardemos los nombres de archivos en un vector de caracteres
archivos <- list.files(directorio_datas, pattern = "*.csv")

# Vamos a aplicar la lectura de datos a través de la librería rio 
install.packages("rio")
library(rio)

# Exploremos solo una data

df_test <- rio::import(paste0(directorio_datas, "/", archivos[1]))

# Podemos leer las 284 bases de datos de forma simultánea con un bucle for
inicio <- Sys.time() # Contemos el tiempo

df <- data.frame() # Data frame vacío auxiliar
data <- data.frame() # Data frame vacío con el resultado final

for(i in archivos){
  df <- rio::import(paste0(directorio_datas, "/", i)) # Primer paso
  
  print(head(df))
  
  colnames(df) <- tolower(colnames(df))
  
  data <- rbind(data, df)
  
}

# Tiempo de ejecución
Sys.time()-inicio # 

# También podemos usar las funciones maps de la librería purrr (taller 4)

# Limpiamos un poco la memoria 
dfs <-  as.list(ls(pattern = "data")) # Vector con nombres de objetos con cierto patrón
rm(list=ls()[! ls() %in% c(dfs)])

#########################z###############################################/
# 2. Librerias de Tidyverse -------------
########################################################################/
# Puedes revisar el detalle de cada librería en: https://www.tidyverse.org/

# dplyr: procesamiento de variables y datos.
# tidyr: trabajo con bases de datos ordenadas. 
# readr: lectura de bases de datos. 
# purrr: Herramienta para trabajar funciones, vectores e iteraciones. 
# tibble: gestiñon de marco de datos. 
# stringr: trabajo con variables de tipo caracter (textos).
# forcats: trabajo con variables de tipo factor (variables cualitativas). 
# ggplot2: visualización de datos. 

# Para instalar todas estas librerías
install.packages("tidyverse")

########################################################################/
# 3. Exploración de los datos -------------
########################################################################/

# La librería dplyr cuenta con funciones para la exploración y manipulación de datos
library(dplyr) 
# Uso del operador pipe %>% 
data %>% glimpse() # Vista previa 
data %>% head()    # Primera 6 observaciones
data %>% colnames() # Nombres columnas/variables
data %>% select(v1, area, months) %>% head()

# Primer problema: a veces es un poco problemático trabajar con variables 
# que cuentan mayúsculas o carateres especiales: "ñ", "´".
# Opten por estandarizar el lenguaje

########################################################################/
# 4. Procesamiento de datos  -------------
########################################################################/

## 4.1 Select -------------
# Seleccionamos columnas/variables
data1 <- data %>% select(1:3,15:60)
data2 <- data %>% select("v1", "area", "months", "y1961":"y1971")
data3 <- data %>% select("v1", "area", "months", "y2018","y2019")

data1 %>% colnames()
data2 %>% colnames()
data3 %>% colnames()

## 4.2 Rename -------------

data2 <- data2 %>% rename(id=area)
data3 <- data3 %>% rename(folio=area)

## 4.3 Filter -------------
# Filtramos por una condición 
table(data1$months) 
data_jan <- data1 %>% filter(months=="January") # Datos solo para enero
data_no_jan <- data1 %>% filter(months!="January") # Datos para el resto de los meses

# Verificamos la cantidad de filas
nrow(data1)
nrow(data_jan) + nrow(data_no_jan)

# Generamos dos condicionnes:
data_temp <- data3 %>% filter(y2018>=0 & y2019==0)
data_temp2 <- data3 %>% filter(y2018>=0 | y2019==0)

nrow(data_temp) # N de la muestra
nrow(data_temp2) # N de la muestra

## 4.4 Arrange -------------
# Ordenamos la BBDD con una variable 
head(data2, n=15)

data_arrange <- data2 %>% arrange(months)  # Por defecto el orden es creciente
head(data_arrange, n=15)

data_arrange2 <- data2 %>% arrange(desc(months)) # Decreciente
head(data_arrange2, n=15)

########################################################################/
# 5. Fundir BBDD -------------
########################################################################/

## 5.1 Append BBDD  -----------------------------------

# Dplyr
glimpse(data_jan)
glimpse(data_no_jan)

data_append <- data_jan %>% add_row(data_no_jan) 
glimpse(data_append )

# R Base:
data_append2 <- rbind(data_jan, data_no_jan)

# Debemos re-ordenar nuestros datos
head(data_append)
data_append <- data_append %>% arrange(area, v1)

# ¿Qué pasa cuando no tenemos la misma cantidad de variable 
data_jan2 <- data_jan %>% select(!months)

data_append <- data_jan2 %>% add_row(data_no_jan) 
data_append2 <- rbind(data_jan2, data_no_jan)

# Ya hay una función programada para este escenario
data_append3 <- data_jan2 %>% bind_rows(data_no_jan) 

# Veamos que realizo la función para solucionar el problema

data_append3[is.na(data_append3$months),]

## 5.2 Join /Antijoin  -----------------------------------

# Veamos esto con un ejemplo sencillo
x <- data.frame(idx = 1:5, letras = letters[1:5])
y <- data.frame(idy = c(2:6,7), num = c(12:16,3))

x
y

# Trae los resultados de las tablas que cumplen con la condición de comparación entre columnas.
x %>% inner_join(y, by=c("idx"="idy")) #Utilizan una lleva para realizar el match. Solo los match.

# Lo podemos guardar
xy <- x %>% inner_join(y, by=c("idx"="idy"))

# Trae todos los resultados de las tablas que cumplen con la condición de comparación entre columnas
# y, adicionalmente, trae todos los datos de la tabla de la izquierda.
x %>% left_join(y, by=c("idx"="idy"))

# Trae todos los resultados de las tablas que cumplen con la condición de comparación entre columnas
# y, adicionalmente, trae todos los datos de la tabla de la derecha.
x %>% right_join(y, by=c("idx"="idy"))

# Trae los resultados de las tablas que cumplen con la condición de comparación entre columnas, 
# además de los resultados de las o registros de las tablas de la derecha y la izquierda.
x %>% full_join(y, by=c("idx"="idy"))

# Trae los elementos que no tiene información para la base de destino.
x %>% anti_join(y, by=c("idx"="idy"))

# Para el estudio personal
x %>% semi_join(y, by=c("idx"="idy"))

test <- x %>% nest_join(y, by=c("idx"="idy"))
test

# Apliquemos con nuestros datos 
install.packages("countrycode")
library(countrycode)

# Vamos a crear un código ISO para nuestros datos 
codes <- data.frame(id=unique(data$area)) # Tenemos 284 filas

# Agregamos los códigos ISO3c
codes$cod_iso <- countrycode(codes$id, origin = 'country.name', destination = 'iso3c')

# Revisamos nuestros resultados 
table(codes$cod_iso, useNA = "ifany")

# Veamos los casos NA 
codes$id[is.na(codes$cod_iso)]

# Solución para los NA les vamos a pedir que repita el valor original
codes$cod_iso[is.na(codes$cod_iso)] <- codes$id[is.na(codes$cod_iso)]

# Revisamos por última vez
table(codes$cod_iso, useNA = "ifany")

# Agregamos a la data original 
data <- data %>% left_join(codes, by=c("area"="id"))

# Ocupamos otra función de dplyr para reordenar
data <- data %>% relocate(cod_iso)

# Vemos el resultado final 
data <- data %>% relocate(cod_iso)
View(data)

########################################################################/
# 6. Modificación de la estructura de la data -------------
########################################################################/

library(tidyr) # Funciones para hacer esto

View(data) # Datos con estructura wide (a lo ancho)

### 6.1 Formato Long  ---------------------------

# Transformemos los datos a estructura long (a lo largo)
data_long <- data %>%
  pivot_longer(cols=!c("cod_iso", "v1", "area", "months"), names_to="year", values_to = "temperature_change")

View(data_long) # Vemos el resultado

### 6.2 Formato Wide ---------------------------

# Si queremos volver al formato wide (a lo ancho)
data_wide <- data_long %>%
  pivot_wider(id_cols=c("cod_iso", "v1", "area", "months"), names_from="year", values_from = "temperature_change")

View(data_wide) # Vemos el resultado

# En algunos casos un formato es más útil que otro. Todo va a depender de nuestro objetivo
# Vamos a quedarnos con nuestra data en formato long

########################################################################/
# 7. Procesamiento de variables -------------
########################################################################/
# Vamos a despejar la memoria 
dfs <-  as.list(ls(pattern = "data")) # Vector con nombres de objetos con cierto patrón
rm(list=ls()[! ls() %in% c(dfs)])

## 7.1 Ajustamos una variable de tipo caracter  ---------------------------
library(stringr)

table(data_long$year, useNA = "ifany")
class(data_long$year)

data_long <- data_long %>% 
  mutate(year=str_replace(year,"y",""))

table(data_long$year, useNA = "ifany")

glimpse(data_long)

## 7.2 Ajustamos una fecha ---------------------------

# Ojo que nuestros meses están en inglés.
# Tenemos que acomodar ese preambulo antes de:
Sys.setlocale(category = "LC_ALL", "en_US.UTF-8") # Ajuste de idioma

data_long <- data_long %>%
  mutate(date=as.Date(paste(months, "15", year), format="%b %d %Y"))

View(data_long)
glimpse(data_long)
class(data_long$date)


## 7.3 Ajustamos una variable continua---------------------------

# Vamos a transformar la variable cambio de temperatura a un puntaje z
mean(data_long$temperature_change, na.rm = TRUE)
sd(data_long$temperature_change, na.rm = TRUE)
summary(data_long$temperature_change)

data_long <- data_long %>% 
  mutate(temperature_change_z=((temperature_change-mean(temperature_change, na.rm=TRUE))/sd(temperature_change, na.rm=TRUE)))

# Vemos el resultado final
mean(data_long$temperature_change_z, na.rm = TRUE)
sd(data_long$temperature_change_z, na.rm = TRUE)
summary(data_long$temperature_change_z)

## 7.4 Generemos un factor (categórica)  ---------------------------

summary(data_long$temperature_change, na.rm = TRUE)
table(data_long$temperature_change, useNA = "ifany")
summary(is.na(data_long$temperature_change)) # Veamos los missing

# Vamos a generar una variable categórica de 3 grupos
# 25% "Bajo" (1)
# 50% "Normal"   (2) 
# 25% "Alto" (3)

#### 7.4.1 if_else()  ---------------------------
quantile(data_long$temperature_change, probs = 0.25, na.rm = T)
quantile(data_long$temperature_change, probs = 0.75, na.rm = T)

# Ajustamos las categorías
data_long <- data_long %>% 
  mutate(prom_cat = if_else(temperature_change<=quantile(temperature_change, probs = 0.25, na.rm = T), 1, 
                            if_else(temperature_change>quantile(temperature_change, probs = 0.25, na.rm = T) &
                                      temperature_change<quantile(temperature_change, probs = 0.75, na.rm = T),2,
                                    if_else(temperature_change>=quantile(temperature_change, probs = 0.75, na.rm = T), 3, NA_real_))))

# Validamos 
table(data_long$prom_cat, useNA = "ifany")
aggregate(data_long$temperature_change~data_long$prom_cat, FUN=summary)

# Vemos los resultados
data_long %>% select(temperature_change, prom_cat) %>% head(n=20)

# Generamos el factor con las categorías
data_long <- data_long %>% mutate(prom_cat=factor(prom_cat, 
                                                  levels=c(1,2,3), 
                                                  labels = c("Bajo cambio",
                                                             "Se mantiene",
                                                             "Alto cambio")))

# Vemos los resultados
data_long %>% select(temperature_change, prom_cat) %>% head(n=20)
table(data_long$prom_cat, useNA = "ifany")

#### 7.4.2 case_when()  ---------------------------
data_long <- data_long %>% 
  mutate(prom_cat2 =  case_when(temperature_change <= quantile(temperature_change, probs = 0.25, na.rm = T)    ~ 1, 
                                temperature_change > quantile(temperature_change, probs = 0.25, na.rm = T) & 
                                  temperature_change < quantile(temperature_change, probs = 0.75, na.rm = T) ~ 2, 
                                temperature_change >= quantile(temperature_change, probs = 0.75, na.rm = T)    ~ 3, 
                                TRUE ~ NA_real_))

# Validamos 
table(data_long$prom_cat, data_long$prom_cat2, useNA = "ifany")

data_long %>% select(temperature_change, prom_cat, prom_cat2) %>% head(n=20)

#### 7.4.3 Indexación  ---------------------------
data_long$prom_cat3[data_long$temperature_change <= quantile(data_long$temperature_change, probs = 0.25, na.rm = T)] <- 1
data_long$prom_cat3[data_long$temperature_change >  quantile(data_long$temperature_change, probs = 0.25, na.rm = T) & 
                             data_long$temperature_change < quantile(data_long$temperature_change, probs = 0.75, na.rm = T)] <- 2
data_long$prom_cat3[data_long$temperature_change >= quantile(data_long$temperature_change, probs = 0.75, na.rm = T)] <- 3

# Validamos 
table(data_long$prom_cat, data_long$prom_cat3, useNA = "ifany")

data_long %>% select(temperature_change, prom_cat, prom_cat2, prom_cat3) %>% head(n=20)

# Eliminamos variables creadas
data_long$prom_cat2 <- NULL
data_long$prom_cat3 <- NULL

## 8  Guardamos en distintos formatos  ---------------------------

## 8.1 Base en formato .txt  ----------------------------------------------------------------
write.table(data_long, file="04_output/cambio_climatico.txt", sep="\t")

## 8.2 Base en formato .csv  ----------------------------------------------------------------
write.csv(data_long, file="04_output/cambio_climatico.csv", row.names = FALSE)

## 8.3 Base en formato .xlsx  ----------------------------------------------------------------
library(writexl)
write_xlsx(data_long, path ="04_output/cambio_climatico.xlsx")

## 8.4 Base en formato .sav  ----------------------------------------------------------------
library(haven)
write_sav(data_long, "04_output/cambio_climatico.sav")

## 8.5 Base en formato .sas  ----------------------------------------------------------------
write_sas(data_long, "04_output/cambio_climatico.sas7bdat")

## 8.5 Base en formato .dta  ----------------------------------------------------------------
write_dta(data_long, "04_output/cambio_climatico.dta")

## 8.6 Base en formato .Rdata  ----------------------------------------------------------------
save(data_long, file="04_output/cambio_climatico.Rdata")

## 8.7 Base en formato .rds  ----------------------------------------------------------------
saveRDS(data_long, "04_output/cambio_climatico.rds")

########################################################################/
# 8. Visualización -------------
########################################################################/

# Vamos a generar un gráfico para cada area (284 gráficos)
library(ggplot2)
library(janitor) # Para limpiar los nombres de los files finales

areas <- unique(data_long$area)

for(i in seq_along(areas)){
  
  fig <- data_long %>%
    filter(area==areas[i]) %>%
    ggplot(aes(x=date, y=temperature_change, group=1)) +
    geom_point(aes(y=temperature_change), shape=1, size=0.5, color="#F5B041") +
    geom_line(aes(y=temperature_change), size=0.75, linetype=1, color="#F5B041") +
    geom_text(data = . %>% filter(date == max(date)),
              aes(label = paste0(round(temperature_change, 1), "ºC")),
              vjust = 0.3, hjust = -0.1,
              show.legend = FALSE, fontface="bold") +
    geom_text(data = . %>% filter(date == min(date)),
              aes(label = paste0(round(temperature_change, 1), "ºC")),
              vjust = 0.3, hjust = 1,
              show.legend = FALSE, fontface="bold") +
    scale_x_date(breaks = "7 year",
                 date_labels = "%Y") +
    labs(x="Serie temporal (años)",
         y = "Cambio de temperatura",
         title=paste("Área:", areas),
         caption="Elaboración propia a partir de los datos de cambio de temperatura entre 1961 - 2019") +
    theme_light(base_size = 10) +
    theme(axis.text.x=element_text(size=10,  vjust=0.5, angle = 0),
          axis.text.y=element_text(size=10),
          plot.title = element_text(size=12, hjust=0.0),
          legend.position="none",
          strip.text = element_text(size = 12, face = "bold", color = "gray40"),
          strip.background = element_rect(fill="white", colour="gray60", linetype="solid"),
          panel.grid.minor = element_blank(),
          panel.grid.major = element_blank())
  
  #Guardamos la figura
  ggsave(plot = fig,
         filename = paste0("04_output/figuras/fig_", janitor::make_clean_names(areas[i]), ".png"),
         res = 300,
         width = 25,
         height = 15,
         units = 'cm',
         scaling = 1,
         device = ragg::agg_png)
}

# Revisamos nuestro resultado en la carpeta 

########################################################################/
# FIN TALLER 2 -------------
########################################################################/
